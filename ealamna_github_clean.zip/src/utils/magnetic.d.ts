export function setupMagneticButtons(): () => void;
